<!-- Issue with the desktop app? Those go here: https://github.com/feross/webtorrent-desktop/issues -->

* WebTorrent version:
* Node.js version:
* Browser name/version (if using WebTorrent in the browser):
